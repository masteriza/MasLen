package com.drew;

import java.io.IOException;
import java.util.Arrays;
import java.util.Date;

import com.drew.converters.ProcessorXlsFo2Pdf;
import com.drew.model.test.OrderTt;
import com.drew.model.test.Tt;
import org.apache.avalon.framework.configuration.ConfigurationException;
import org.xml.sax.SAXException;

public class Tester {
    private static String pdfPathName_po = "C:/dev.src/PrintModule/PO.pdf";
    private static String xlsFoPathName_ppo = "C:\\dev.src\\PrintModule\\src\\main\\resources\\xsl\\ppo.xsl";
    private static String xlsFoPathName_PurchaseOrder = "C:\\dev.src\\PrintModule\\src\\main\\resources\\xsl\\PurchaseOrder.xsl";

   /* public static IPurchaseOrder getPurchaseOrder() {
        IPurchaseOrder po = new PurchaseOrder("PO-123-456789");
        po.setOrderDate(new Date());

        IAddress coAddress = new Address();
        coAddress.setCompanyName("ACME Company");
        coAddress.setStreetAddress("123 Main Street");
        coAddress.setCity("Orlando");
        coAddress.setState("FL");
        coAddress.setZipCode("32801");
        po.setCompanyAddress(coAddress);

        IAddress custAddress = new Address();
        custAddress.setCompanyName("A++");
        custAddress.setStreetAddress("123 8th Avenue");
        custAddress.setCity("Orlando");
        custAddress.setState("FL");
        custAddress.setZipCode("32801");
        po.setCustomerAddress(custAddress);

        IOrderItem item = new OrderItem();
        item.setItemId("A1B2C3");
        item.setItemName("Widget");
        item.setQuantity(100);
        item.setItemCost(100.50f);
        po.addItem(item);

        item = new OrderItem();
        item.setItemId("C3B2A1");
        item.setItemName("Micro-Widget");
        item.setQuantity(1000);
        item.setItemCost(10.750f);
        po.addItem(item);

        return po;
    }*/

    public static OrderTt getOrderTt() {
        return new OrderTt(new Tt("It`s works"), Arrays.asList(new Tt("item 1"), new Tt("item 1")));
    }

    public static void main(String[] args) throws IOException, SAXException, ConfigurationException {
        String xLStemplate = "xsl\\PurchaseOrder.xsl";
//        new ProcessorXlsFo2Pdf(getOrderTt(), pdfPathName_po, xlsFoPathName_ppo).generate();
        new ProcessorXlsFo2Pdf(getOrderTt(), xlsFoPathName_ppo, xLStemplate).generate1();
    }
}
