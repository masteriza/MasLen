package com.drew.converters;

import com.drew.interfaces.IXmlSerializable;
import org.apache.avalon.framework.configuration.ConfigurationException;
import org.xml.sax.SAXException;

import java.io.*;

public class ProcessorXlsFo2Pdf {
    private IXmlSerializable obj;
    private String pdfPathName;
    private String xlsTemplate;

    public ProcessorXlsFo2Pdf(IXmlSerializable obj, String pdfPathName, String xlsTemplate) {
        this.pdfPathName = pdfPathName;
        this.xlsTemplate = xlsTemplate;
        this.obj = obj;
    }

    public void generate() throws IOException, SAXException, ConfigurationException {
        BufferedOutputStream pdfContent = null;
        try {
//            ByteArrayOutputStream

            File xls = new File(getClass().getClassLoader().getResource(xlsTemplate).getFile());
            FileInputStream xlsInputStream = new FileInputStream(xls);
            pdfContent = new BufferedOutputStream(new FileOutputStream(new File(pdfPathName)));
            new PdfGenerator().generate(obj, xlsInputStream, pdfContent);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } finally {
            if (pdfContent != null)
                try {
                    pdfContent.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
        }
    }

    public void generate1() throws IOException, SAXException, ConfigurationException {
        ByteArrayOutputStream pdfContent = null;
        try {
            File xls = new File(getClass().getClassLoader().getResource(xlsTemplate).getFile());
            FileInputStream xlsInputStream = new FileInputStream(xls);
            pdfContent = new ByteArrayOutputStream();

            OutputStream generate = new PdfGenerator().generate(obj, xlsInputStream, pdfContent);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } finally {
            if (pdfContent != null)
                try {
                    pdfContent.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
        }
    }
}
