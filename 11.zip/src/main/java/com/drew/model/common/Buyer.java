package com.drew.model.common;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import lombok.Data;

@Data
public class Buyer {
    private Long id;
    @XStreamAlias("fio")
    private String fio;
    @XStreamAlias("email")
    private String email;
    @XStreamAlias("phone")
    private String phone;
    @XStreamAlias("passport")
    private Passport passport;
}
