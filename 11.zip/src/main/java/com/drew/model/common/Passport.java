package com.drew.model.common;

import com.drew.interfaces.IXmlSerializable;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import lombok.Data;

@Data
@XStreamAlias("Passport")
public class Passport implements IXmlSerializable {
    private Long id;
    @XStreamAlias("serial")
    private String serial;
    @XStreamAlias("number")
    private String number;
    @XStreamAlias("reg")
    private String registrationPlace;

    public Passport() {
    }

    public Passport(String serial, String number, String registrationPlace) {
        this.serial = serial;
        this.number = number;
        this.registrationPlace = registrationPlace;
    }

    @Override
    public String toXml() {
        XStream xstream = new XStream();
        xstream.autodetectAnnotations(true);
        return xstream.toXML(this);
    }
}
