package com.drew.model.common;

import lombok.Data;

import java.sql.Clob;

@Data
public class Template {
    private Long id;
    private Long version;
    private Clob body;
}
