package com.drew.model.common.bucket;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class Item {
    private Long id;
    private Product product;
    private int quantity;
    private BigDecimal pricePdf;
    private BigDecimal summaryPdf;
}
