package com.drew.model.common.bucket;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

@Data
public class Order {
    private Long id;
    private List<Item> items;
    @XStreamAlias("InvoiceCreateDate")
    private BigDecimal totalWithPdf;
}
