package com.drew.model;

import com.drew.model.common.Buyer;
import com.drew.model.common.Passport;
import com.drew.model.common.Template;
import com.drew.model.common.bucket.Item;
import com.drew.model.common.bucket.Order;
import com.drew.model.common.bucket.Product;
import com.drew.model.ttn.DocPack;
import com.drew.model.ttn.OInvoice;
import com.drew.model.ttn.RInvoice;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;

public class DataOrder {
    public static DocPack getPackage() {
        OInvoice OInvoice = new OInvoice();
        {
            OInvoice.setId(11L);
            {
                OInvoice.setNumber("this is OInvoice number");
                OInvoice.setTtnCreateDate(LocalDate.now());
                OInvoice.setRegNumber("This is reg number");
                OInvoice.setOrderNumber("This is order number");
                OInvoice.setOrderCreateDate(LocalDate.now());
                {
                    Template template = new Template();
                    template.setId(22L);
                    template.setVersion(33L);
                    template.setBody(null);
                    OInvoice.setTemplate(template);
                }
                {
                    Buyer buyer = new Buyer();
                    buyer.setId(33l);
                    buyer.setEmail("sa@gmail.com");
                    buyer.setPhone("+380501807377");
                    buyer.setFio("Ivanov Ivan");
                    {
                        Passport passport = new Passport();
                        passport.setId(555L);
                        passport.setNumber("12345");
                        passport.setSerial("BB");
                        passport.setRegistrationPlace("Registration place");
                        buyer.setPassport(passport);
                    }
                    OInvoice.setBuyer(buyer);
                }
                {
                    Order order = new Order();
                    order.setId(777L);
                    order.setTotalWithPdf(new BigDecimal(10));
                    Item item11 = new Item();
                    {
                        item11.setId(21L);
                        item11.setQuantity(2);
                        item11.setPricePdf(new BigDecimal(200));
                        item11.setSummaryPdf(new BigDecimal(400));
                        {
                            Product product = new Product();
                            product.setId(31L);
                            product.setArticul("art 001");
                            product.setModel("model X");
                            product.setName("Super product");
                            item11.setProduct(product);
                        }
                    }
                    Item item12 = new Item();
                    {
                        item12.setId(212L);
                        item12.setQuantity(1);
                        item12.setPricePdf(new BigDecimal(50));
                        item12.setSummaryPdf(new BigDecimal(50));
                        {
                            Product product = new Product();
                            product.setId(311L);
                            product.setArticul("art 000");
                            product.setModel("nope");
                            product.setName("Delivery");
                            item12.setProduct(product);
                        }
                    }
                    order.setItems(Arrays.asList(item11, item12));
                    OInvoice.setOrder(order);
                }
            }
        }
        RInvoice RInvoice = new RInvoice();
        {
            RInvoice.setId(2L);
            RInvoice.setNumber("return number");
            RInvoice.setTtnCreateDate(LocalDate.now().plusDays(10));
            {
                Template template = new Template();
                template.setId(21L);
                template.setVersion(31L);
                template.setBody(null);
                RInvoice.setTemplate(template);
            }
            RInvoice.setOInvoice(OInvoice);
            RInvoice.setToReturn(OInvoice.getOrder());
        }

        DocPack pack = new DocPack();
        pack.setId(1L);
        pack.setOInvoice(OInvoice);
        pack.setRInvoice(RInvoice);
        return pack;
    }
}
