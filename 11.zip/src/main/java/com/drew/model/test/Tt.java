package com.drew.model.test;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("Tt")
public class Tt {
    @XStreamAlias("test")
    private String test;

    public Tt() {
    }

    public Tt(String test) {
        this.test = test;
    }
}
