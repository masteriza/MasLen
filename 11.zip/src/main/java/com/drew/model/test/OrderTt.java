package com.drew.model.test;

import com.drew.interfaces.IXmlSerializable;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.annotations.XStreamAlias;

import java.util.ArrayList;
import java.util.List;

@XStreamAlias("OrderTt")
public class OrderTt implements IXmlSerializable {
    @XStreamAlias("Tt")
    private Tt tt;
    @XStreamAlias("list")
    private List<Tt> list;

    public OrderTt() {
        list = new ArrayList<>();
    }

    public OrderTt(Tt tt, List<Tt> list) {
        this();
        this.tt = tt;
        this.list = list;
    }

    @Override
    public String toXml() {
        XStream xstream = new XStream();
        xstream.autodetectAnnotations(true);
        return xstream.toXML(this);
    }
}
