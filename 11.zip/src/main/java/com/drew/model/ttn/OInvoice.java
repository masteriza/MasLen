package com.drew.model.ttn;

import com.drew.model.common.Buyer;
import com.drew.model.common.Template;
import com.drew.model.common.bucket.Order;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import lombok.Data;

import java.time.LocalDate;

@Data
public class OInvoice {
    private Long id;
    private Template template;
    @XStreamAlias("invoice")
    private String number;
    @XStreamAlias("invoiceCreateDate")
    private LocalDate ttnCreateDate;
    @XStreamAlias("invoiceRegNumber")
    private String regNumber;
    @XStreamAlias("invoiceOrderNumber")
    private String orderNumber;
    @XStreamAlias("orderCreateDate")
    private LocalDate orderCreateDate;

    private Buyer buyer;
    private Order order;
}
