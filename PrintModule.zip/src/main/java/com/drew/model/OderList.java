package com.drew.model;

import com.drew.model.common.bucket.Item;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class OderList {
    private List<Item> items = new ArrayList<>();

    public OderList(List<Item> items) {
        this.items = items;
    }

    public OderList() {
    }
}
