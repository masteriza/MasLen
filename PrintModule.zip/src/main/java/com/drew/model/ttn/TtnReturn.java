package com.drew.model.ttn;

import com.drew.model.common.Template;
import com.drew.model.common.bucket.Order;
import lombok.Data;

import java.time.LocalDate;

@Data
public class TtnReturn {
    private Long id;
    private Template template;
    private String number;
    private LocalDate ttnCreateDate;
    private Ttn ttn;
    private Order toReturn;
}
