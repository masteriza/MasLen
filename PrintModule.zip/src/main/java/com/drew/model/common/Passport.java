package com.drew.model.common;

import lombok.Data;

@Data
public class Passport {
    private Long id;
    private String serial;
    private String number;
    private String registrationPlace;
}
