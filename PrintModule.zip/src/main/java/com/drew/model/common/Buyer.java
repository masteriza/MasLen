package com.drew.model.common;

import lombok.Data;

@Data
public class Buyer {
    private Long id;
    private String fio;
    private String email;
    private String phone;
    private Passport passport;
}
