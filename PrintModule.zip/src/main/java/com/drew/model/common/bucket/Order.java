package com.drew.model.common.bucket;

import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

@Data
public class Order {
    private Long id;
    private List<Item> items;
    private BigDecimal totalWithPdf;
}
