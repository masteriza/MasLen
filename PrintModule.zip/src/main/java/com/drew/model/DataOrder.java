package com.drew.model;

import com.drew.model.common.Buyer;
import com.drew.model.common.Passport;
import com.drew.model.common.Template;
import com.drew.model.common.bucket.Item;
import com.drew.model.common.bucket.Order;
import com.drew.model.common.bucket.Product;
import com.drew.model.ttn.DocPack;
import com.drew.model.ttn.Ttn;
import com.drew.model.ttn.TtnReturn;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;

public class DataOrder {
    public static DocPack getPackage() {
        Ttn ttn = new Ttn();
        {
            ttn.setId(11L);
            {
                ttn.setNumber("this is ttn number");
                ttn.setTtnCreateDate(LocalDate.now());
                ttn.setRegNumber("This is reg number");
                ttn.setOrderNumber("This is order number");
                ttn.setOrderCreateDate(LocalDate.now());
                {
                    Template template = new Template();
                    template.setId(22L);
                    template.setVersion(33L);
                    template.setBody(null);
                    ttn.setTemplate(template);
                }
                {
                    Buyer buyer = new Buyer();
                    buyer.setId(33l);
                    buyer.setEmail("sa@gmail.com");
                    buyer.setPhone("+380501807377");
                    buyer.setFio("Ivanov Ivan");
                    {
                        Passport passport = new Passport();
                        passport.setId(555L);
                        passport.setNumber("12345");
                        passport.setSerial("BB");
                        passport.setRegistrationPlace("Registration place");
                        buyer.setPassport(passport);
                    }
                    ttn.setBuyer(buyer);
                }
                {
                    Order order = new Order();
                    order.setId(777L);
                    order.setTotalWithPdf(new BigDecimal(10));
                    Item item1 = new Item();
                    {
                        item1.setId(21L);
                        item1.setQuantity(2);
                        item1.setPricePdf(new BigDecimal(200));
                        item1.setSummaryPdf(new BigDecimal(400));
                        {
                            Product product = new Product();
                            product.setId(31L);
                            product.setArticul("art 001");
                            product.setModel("model X");
                            product.setName("Super product");
                            item1.setProduct(product);
                        }
                    }
                    Item item2 = new Item();
                    {
                        item2.setId(212L);
                        item2.setQuantity(1);
                        item2.setPricePdf(new BigDecimal(50));
                        item2.setSummaryPdf(new BigDecimal(50));
                        {
                            Product product = new Product();
                            product.setId(311L);
                            product.setArticul("art 000");
                            product.setModel("nope");
                            product.setName("Delivery");
                            item2.setProduct(product);
                        }
                    }
                    order.setItems(Arrays.asList(item1, item2));
                    ttn.setOrder(order);
                }
            }
        }
        TtnReturn ttnReturn = new TtnReturn();
        {
            ttnReturn.setId(2L);
            ttnReturn.setNumber("return number");
            ttnReturn.setTtnCreateDate(LocalDate.now().plusDays(10));
            {
                Template template = new Template();
                template.setId(21L);
                template.setVersion(31L);
                template.setBody(null);
                ttnReturn.setTemplate(template);
            }
            ttnReturn.setTtn(ttn);
            ttnReturn.setToReturn(ttn.getOrder());
        }

        DocPack pack = new DocPack();
        pack.setId(1L);
        pack.setTtn(ttn);
        pack.setTtnReturn(ttnReturn);
        return pack;
    }
}
