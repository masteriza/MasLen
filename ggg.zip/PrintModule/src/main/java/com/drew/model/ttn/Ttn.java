package com.drew.model.ttn;

import com.drew.model.common.Buyer;
import com.drew.model.common.Template;
import com.drew.model.common.bucket.Order;
import lombok.Data;

import java.time.LocalDate;

@Data
public class Ttn {
    private Long id;
    private Template template;

    private String number;
    private LocalDate ttnCreateDate;
    private String regNumber;
    private String orderNumber;
    private LocalDate orderCreateDate;

    private Buyer buyer;
    private Order order;
}
