package com.drew.model.ttn;

import lombok.Data;

@Data
public class DocPack {
    private Long id;
    private Ttn ttn;
    private TtnReturn ttnReturn;
}
