package com.drew.model.test;

import com.drew.interfaces.IOrderItem;
import com.drew.interfaces.IXmlSerializable;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@XStreamAlias("Class")
public class UniversityClass implements IXmlSerializable {
    @XStreamAlias("name")
    @XStreamAsAttribute
    private String name;
    @XStreamAlias("students")
    @XStreamAsAttribute
    private ArrayList<Student> students = new ArrayList<>();

    public Iterator<Student> getStudents() {
        return this.students.iterator();
    }

    public int getStudentCount() {
        return this.students.size();
    }

    public void addStudent(Student detail) {
        this.students.add(detail);
        ;
    }


    public void setStudent(ArrayList<Student> students) {
        this.students = students;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public UniversityClass() {
    }

    @Override
    public String toXml() {
        XStream xstream = new XStream();
        xstream.autodetectAnnotations(true);
        return xstream.toXML(this);
    }
}
