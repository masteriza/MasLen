package com.drew.model.test;

import com.drew.interfaces.IXmlSerializable;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

@XStreamAlias("Student")
public class Student implements IXmlSerializable {
    @XStreamAlias("fio")
    @XStreamAsAttribute
    private String fio;
    @XStreamAlias("grade")
    @XStreamAsAttribute
    private Integer grade;

    public Student(String fio, Integer grade) {
        this.fio = fio;
        this.grade = grade;
    }

    public Student() {
    }

    public String getFio() {
        return fio;
    }

    public void setFio(String fio) {
        this.fio = fio;
    }

    public Integer getGrade() {
        return grade;
    }

    public void setGrade(Integer grade) {
        this.grade = grade;
    }

    @Override
    public String toXml() {
        XStream xstream = new XStream();
        xstream.autodetectAnnotations(true);
        return xstream.toXML(this);
    }
}
