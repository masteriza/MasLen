package com.drew.model.common.bucket;

import lombok.Data;

@Data
public class Product {
    private Long id;
    private String articul;
    private String model;
    private String name;
}
