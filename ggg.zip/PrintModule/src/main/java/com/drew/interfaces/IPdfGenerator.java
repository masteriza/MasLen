package com.drew.interfaces;

import java.io.OutputStream;

/**
 * The Interface IPdfGenerator.
 */
public interface IPdfGenerator {
	
	/**
	 * Generate.
	 * 
	 * @param object the object
	 * @param stylesheetPath the stylesheet path
	 * @param pdfContent the pdf content
	 * 
	 * @return the output stream
	 */
	OutputStream generate(IXmlSerializable object, String stylesheetPath, OutputStream pdfContent);
}
