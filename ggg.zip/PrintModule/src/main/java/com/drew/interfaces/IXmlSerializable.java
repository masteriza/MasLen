package com.drew.interfaces;

public interface IXmlSerializable {

	/**
	 * Converts object to XML.
	 * 
	 * @return the string
	 */
	String toXml();
}
